# GranGameJam

## This Is Halloween
In this game you have to walk through a cementery and defeat all the monsters that you find in our way.

## Controls

__W:__ Up

__S:__ Down

__A:__ Left

__D:__ Right


__Space:__ Dash

__Left Mouse Click__ Shot

## Team
__[Artist]:__ [Yessica Servin](https://github.com/YessicaSD)

__[Programmer]:__ [Alex Morales](https://github.com/AlexMG99?tab=following) & [Yessica Servin](https://github.com/YessicaSD)

__[Designer]:__ [Josep Pi](https://github.com/joseppi)


## Disclaimer
We don't own any art of this game. We used free art from other artists.
- Except the player, that was made by Yessica Servin

## Find this project on Github
 https://github.com/RainbowBehaveour/GranGameJam
 
 ## License
 
 MIT License

Copyright (c) [2018] [Alex Morales, Yessica Servin & Josep Pi]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

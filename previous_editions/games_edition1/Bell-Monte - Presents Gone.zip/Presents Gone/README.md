﻿# Game Tittle: Presents Gone

## Current Version
v1.0

## Description
This is a Point and clicking Game about a child without presents on christmas.

### Installing
Go to our github release page and download the las version .zip : 

```
https://github.com/LITTLE-BUSTERS-STUDIO/FallSlime/releases
```
Extract .zip files inside a folder and open the .exe file.

#### Controls:
* **Mouse Left Click** -Interact

## Authors & Links
* **Alejandro Gamarra (alejandro61299)** 
* **Marc Galvez(optus23)**
* **Roger Sanchez March(RogerJimbo)**
* **Marc Fabián i Vilà(xDragan)**

Github repository: https://github.com/alejandro61299/GameJam3.0

# We hope you Enjoy! Thanks for playing.

MIT License

Copyright (c) 2018 @alejandro61299 (Alejandro Gamarra Niño), @optus23 (Marc Gálvez Llorens), @RogerJimbo (Roger Sanchez March),@xDragan(Marc Fabián i Vilà)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
